<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Cevapovic\Serije;
use Cevapovic\Projekt;
use Composer\Autoload\ClassLoader;

Flight::route('/', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/rcevapovic_19/rcevapovic.rdf');
  $info = $foaf->dump();
  echo "<h2>Ontologija P3 zadatka:</h2> <br/><br/>" . $info;
});

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Cevapovic\Serije');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});


Flight::route('GET /insert', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/rcevapovic_19/rcevapovic.rdf');
  foreach ($foaf->resources() as $resource) {

    $name = $foaf->get($resource, 'foaf:name'); 
    if($name != ''){

      $i = 0;
      $annotations = "";

     
      $description = $foaf->get($resource, 'dc:description'); 
      $creator = $foaf->get($resource, 'dc:creator');
      $language = $foaf->get($resource, 'dc:language');

      foreach ($resource->properties() as $key) {
          $annotations .= $key . ': ' . $foaf->get($resource, $key) . "\n";
      }

      $serije = new Serije();
      $serije->setPodaci(Flight::request()->data);

      $serije->setNazivSerije($name); //https://oziz.ffos.hr/nastava20192020/rcevapovic_19/ontologija/search
      $serije->setZanr($description);
      $serije->setRedatelj($creator);
      $serije->setJezik($language);
      $serije->setAnotacija($annotations);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($serije);
      $em->flush();
    }
  }

  echo "Ontologija je uspješno učitana.";

});

Flight::route('GET /search/@name', function($name){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Cevapovic\Serije');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.nazivSerije LIKE :nazivSerije')
                        ->setParameter('nazivSerije', '%'.$name.'%')
                        ->getQuery()
                        ->getResult();
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Cevapovic', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();

