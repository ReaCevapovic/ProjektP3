create database rcevapovic_19 default character set utf8;
use rcevapovic_19;
create table serije(
    sifra int not null primary key auto_increment,
    nazivSerije varchar(255) not null,
    zanr varchar(100) not null,
    redatelj varchar(100) not null,
    jezik varchar(100) not null,
    anotacija text not null
);
insert into serije(nazivSerije, zanr, redatelj, jezik, anotacija) values ("test", "test", "test", "test", "test");
