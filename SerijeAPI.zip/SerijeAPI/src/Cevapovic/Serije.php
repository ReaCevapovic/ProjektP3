<?php

namespace Cevapovic;

/**
 * @Entity @Table(name="serije")
 **/


class Serije
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $nazivSerije;

    /**
    * @Column(type="string")
    */
    private $zanr;

     /**
    * @Column(type="string")
    */
    private $redatelj;

     /**
    * @Column(type="string")
    */
    private $jezik;

    /**
    * @Column(type="string")
    */
    private $anotacija;

    public function getSifra(){
      return $this->sifra;
    }
  
    public function setSifra($sifra){
      $this->sifra = $sifra;
    }
  
    public function getNazivSerije(){
      return $this->nazivSerije;
    }
  
    public function setNazivSerije($nazivSerije){
      $this->nazivSerije = $nazivSerije;
    }
  
    public function getZanr(){
      return $this->zanr;
    }
  
    public function setZanr($zanr){
      $this->zanr = $zanr;
    }
  
    public function getRedatelj(){
      return $this->redatelj;
    }
  
    public function setRedatelj($redatelj){
      $this->redatelj = $redatelj;
    }
  
    public function getJezik(){
      return $this->jezik;
    }
  
    public function setJezik($jezik){
      $this->jezik = $jezik;
    }
  
    public function getAnotacija(){
      return $this->anotacija;
    }
  
    public function setAnotacija($anotacija){
      $this->anotacija = $anotacija;
    }

 
    
  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
